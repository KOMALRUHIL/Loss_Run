import os
import re
import json
import difflib
import pandas as pd
try:
    import models
except ImportError:
    models = None

try:
    from utils_gpt import gpt_call, _coerce_json_text
except ImportError:
    gpt_call = None
    _coerce_json_text = None

def normalize_name(name: str) -> str:
    """
    Cleans name for comparison: lowercases, removes punctuation,
    and strips extra spaces. Used in fallback logic.
    """
    if pd.isna(name) or not name:
        return ""
    cleaned = str(name).lower()
    cleaned = re.sub(r'[^a-z0-9\s]', '', cleaned)
    cleaned = re.sub(r'\s+', ' ', cleaned).strip()
    return cleaned

def names_match(n1: str, n2: str) -> bool:
    """
    Checks if two normalized names are highly similar or substring matches.
    """
    if not n1 or not n2:
        return False
    if n1 == n2:
        return True
    if n1 in n2 or n2 in n1:
        return True
    similarity = difflib.SequenceMatcher(None, n1, n2).ratio()
    return similarity > 0.85

def get_10_word_desc(desc: str) -> str:
    """
    Normalizes a description to its first 10 alphanumeric words of length > 2.
    """
    if pd.isna(desc) or not desc:
        return ""
    desc_clean = str(desc).strip().lower()
    words = [w for w in re.findall(r'[a-z0-9]+', desc_clean) if len(w) > 2][:10]
    return " ".join(words) if words else ""

def generate_programmatic_roll_numbers(df: pd.DataFrame, step_level: int = 3) -> list:
    """
    Groups claims independently based on the step_level:
    1. ROLLUP_1: Grouped by same loss date, claimant name, and state.
       Format: Always desc_[description_slug]&[date]&[state]
    2. ROLLUP_2: Grouped by claim ID variations and 10-word description.
       Format: [base_claim_id]&[description_slug] if grouped, else desc_[description_slug]&[date]&[state]
    3. ROLLUP_3: Grouped by same loss date, state, and 10-word description.
       Format: Always desc_[description_slug]&[date]&[state]
    """
    import re
    
    n = len(df)
    parent = list(range(n))
    
    def find(i):
        path = []
        while parent[i] != i:
            path.append(i)
            i = parent[i]
        for node in path:
            parent[node] = i
        return i

    def union(i, j):
        root_i = find(i)
        root_j = find(j)
        if root_i != root_j:
            parent[root_i] = root_j

    def clean_str(val):
        if pd.isna(val):
            return ""
        return str(val).strip()

    # Extract cleaned fields for all rows
    rows_data = []
    for idx in range(n):
        row = df.iloc[idx]
        
        # Loss Date
        ld = ""
        for field in ["accident_date", "loss_date"]:
            if field in row:
                val = clean_str(row[field])
                if val and val.lower() not in ["nan", "none"]:
                    ld = val
                    break
                    
        # Claimant Name
        cl = ""
        for field in ["claimant", "driver", "claimant_name", "driver_name"]:
            if field in row:
                val = clean_str(row[field])
                if val and val.lower() not in ["nan", "none"]:
                    cl = val.lower()
                    break
                    
        # State
        st = ""
        for field in ["accident_state", "garage_state", "coverage_state", "state"]:
            if field in row:
                val = clean_str(row[field])
                if val and val.lower() not in ["nan", "none"]:
                    st = val.upper()
                    break
                    
        # Claim ID
        cid = ""
        for field in ["claim_id", "claim_number"]:
            if field in row:
                val = clean_str(row[field])
                if val and val.lower() not in ["nan", "none"]:
                    cid = val
                    break
                    
        # Description
        desc = ""
        for field in ["claim_description", "description", "event_description"]:
            if field in row:
                val = clean_str(row[field])
                if val and val.lower() not in ["nan", "none"]:
                    desc = val
                    break
                    
        rows_data.append({
            "idx": idx,
            "loss_date": ld,
            "claimant": cl,
            "state": st,
            "claim_id": cid,
            "description": desc
        })

    def get_logic2_key(claim_id):
        if not claim_id:
            return ""
        cid_clean = re.sub(r'\s+', '', claim_id).lower()
        if len(cid_clean) < 5:
            return ""
        match = re.search(r'[-_/\s.]([a-zA-Z0-9]{1,4})$', cid_clean)
        if match:
            suffix_len = len(match.group(0))
            base = cid_clean[:-suffix_len]
            if len(base) >= 4:
                return base
            return ""
        else:
            # Simple alphanumeric
            if len(cid_clean) > 2:
                base = cid_clean[:-2]
                if len(base) >= 4:
                    return base
            return ""

    # Perform ONLY the requested independent grouping based on step_level
    if step_level == 1:
        # Group by: loss date, claimant name, and state
        step1_groups = {}
        for r in rows_data:
            ld = r["loss_date"]
            cl = r["claimant"]
            st = r["state"]
            if ld and cl and st:
                key = (ld, cl, st)
                step1_groups.setdefault(key, []).append(r["idx"])
                
        for key, indices in step1_groups.items():
            if len(indices) > 1:
                for idx in indices[1:]:
                    union(indices[0], idx)

    elif step_level == 2:
        # Group by: claim ID variation and 10-word description
        step2_groups = {}
        for idx in range(n):
            cid = rows_data[idx]["claim_id"]
            desc = rows_data[idx]["description"]
            if cid:
                key_id = get_logic2_key(cid)
                if key_id:
                    desc_norm = get_10_word_desc(desc)
                    key = (key_id, desc_norm)
                    step2_groups.setdefault(key, []).append(idx)
                    
        for key, indices in step2_groups.items():
            if len(indices) > 1:
                for idx in indices[1:]:
                    union(indices[0], idx)

    elif step_level == 3:
        # Group by: loss date, state, and 10-word description
        step3_groups = {}
        for idx in range(n):
            ld = rows_data[idx]["loss_date"]
            st = rows_data[idx]["state"]
            desc = rows_data[idx]["description"]
            if ld and st and desc:
                desc_norm = get_10_word_desc(desc)
                key = (ld, st, desc_norm)
                step3_groups.setdefault(key, []).append(idx)
                
        for key, indices in step3_groups.items():
            if len(indices) > 1:
                for idx in indices[1:]:
                    union(indices[0], idx)

    # Assign roll_no for each group
    root_to_members = {}
    for i in range(n):
        root = find(i)
        root_to_members.setdefault(root, []).append(i)
        
    roll_numbers = [None] * n
    for root, members in root_to_members.items():
        m0 = rows_data[members[0]]
        
        if step_level == 1:
            # ROLLUP_1: Always [claimant_slug]&[date_slug]&[state_slug]
            claimant_slug = m0["claimant"].replace(" ", "_") if m0["claimant"] else "unknown"
            date_slug = m0["loss_date"].replace("/", "-").replace(" ", "_") if m0["loss_date"] else "unknown"
            state_slug = m0["state"].replace(" ", "_").lower() if m0["state"] else "unknown"
            roll_no = f"{claimant_slug}&{date_slug}&{state_slug}".lower()
            
        elif step_level == 2:
            # ROLLUP_2: Always [base_claim_id]&[description_slug]
            k0 = get_logic2_key(m0["claim_id"])
            if not k0:
                k0 = "noclaimid"
            desc_norm = get_10_word_desc(m0["description"])
            desc_slug = desc_norm.replace(" ", "_") if desc_norm else "desc"
            roll_no = f"{k0}&{desc_slug}".lower()
            
        elif step_level == 3:
            # ROLLUP_3: Always desc_[description_slug]&[date_slug]&[state_slug]
            desc_norm = get_10_word_desc(m0["description"])
            desc_slug = desc_norm.replace(" ", "_") if desc_norm else "desc"
            date_slug = m0["loss_date"].replace("/", "-").replace(" ", "_") if m0["loss_date"] else "unknown"
            state_slug = m0["state"].replace(" ", "_").lower() if m0["state"] else "unknown"
            roll_no = f"desc_{desc_slug}&{date_slug}&{state_slug}".lower()

        for m in members:
            roll_numbers[m] = roll_no
            
    return roll_numbers

def programmatic_fallback_roll_numbers(df: pd.DataFrame) -> list:
    return generate_programmatic_roll_numbers(df)

def get_llm_roll_numbers(df: pd.DataFrame) -> list:
    return generate_programmatic_roll_numbers(df)

def aggregate_claims(df: pd.DataFrame) -> pd.DataFrame:
    """
    Groups by roll_no and aggregates all claims.
    """
    numeric_cols = [
        "total_incurred",
        "total_paid",
        "total_reserve",
        "incurred_alae",
        "paid_alae",
        "total_recoveries"
    ]
    
    # Coerce numeric columns to float to ensure we sum them properly and don't concatenate strings
    df_clean = df.copy()
    for col in numeric_cols:
        if col in df_clean.columns:
            df_clean[col] = pd.to_numeric(
                df_clean[col].astype(str).str.replace(r'[^\d.-]', '', regex=True),
                errors='coerce'
            ).fillna(0.0)

    agg_funcs = {}
    for col in df_clean.columns:
        if col == 'roll_no':
            continue
        
        if col in numeric_cols:
            agg_funcs[col] = 'sum'
        elif col == 'rolledup':
            agg_funcs[col] = 'first'
        else:
            def _join_unique(series, col_name=col):
                vals = []
                for val in series:
                    if pd.notna(val):
                        s = str(val).strip()
                        if s != "" and s.lower() != "nan":
                            vals.append(s)
                
                unique_vals = []
                for v in vals:
                    if v not in unique_vals:
                        unique_vals.append(v)
                
                if not unique_vals:
                    return ""
                if len(unique_vals) == 1:
                    return unique_vals[0]
                return ", ".join(unique_vals)
                
            agg_funcs[col] = _join_unique

    aggregated = df_clean.groupby('roll_no', as_index=False).agg(agg_funcs)
    
    # Put roll_no first
    cols = ['roll_no'] + [col for col in aggregated.columns if col != 'roll_no']
    aggregated = aggregated[cols]
    
    return aggregated

def run_rollup_post_processing(input_path: str, output_detailed_path: str, output_rollup_path: str):
    """
    Loads, processes, and writes the two output CSV files.
    """
    if not os.path.exists(input_path):
        print(f"[ERROR] Input file {input_path} not found.")
        return

    print(f"Reading claims from: {input_path}")
    df = pd.read_csv(input_path)

    if df.empty:
        print("[INFO] Claims file is empty. Skipping rollup.")
        df.insert(0, 'roll_no', [])
        df.to_csv(output_detailed_path, index=False)
        df.to_csv(output_rollup_path, index=False)
        return

    print("Running LLM rollup logic...")
    roll_numbers = get_llm_roll_numbers(df)
    
    detailed_df = df.copy()
    detailed_df.insert(0, 'roll_no', roll_numbers)
    
    # Calculate rolledup boolean: True if the group has multiple claims, False otherwise
    roll_no_counts = pd.Series(roll_numbers).value_counts()
    detailed_df['rolledup'] = pd.Series(roll_numbers).map(lambda x: roll_no_counts.get(x, 0) > 1).values
    
    rollup_df = aggregate_claims(detailed_df)

    # Write output files
    print(f"Saving detailed claims with roll_no to: {output_detailed_path}")
    detailed_df.to_csv(output_detailed_path, index=False)

    print(f"Saving rolled up claims to: {output_rollup_path}")
    rollup_df.to_csv(output_rollup_path, index=False)
    print("Rollup step completed successfully!")

if __name__ == "__main__":
    # Standard output paths
    input_file = "extraction_output/sample_claims.csv"
    output_detailed = "extraction_output/sample_claims.csv"
    output_rollup = "extraction_output/sample_Rolled_up_claims.csv"
    
    run_rollup_post_processing(input_file, output_detailed, output_rollup)
